from django.apps import AppConfig


class AppBaseConfig(AppConfig):
    name = 'app_base'
