A Pen created at CodePen.io. You can find this one at http://codepen.io/markhillard/pen/Hjcwu.

 This is an HTML5 audio player that detects the user agent of your device/browser/OS and applies styling that matches the native audio player. The playlist responds to the width of your screen and features basic UI controls.

Feel free to fork this pen and add your own user agent styles for different browsers, devices and operating systems.